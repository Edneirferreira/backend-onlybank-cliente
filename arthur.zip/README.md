# Backend Criptomoedas

Esta aplicação possui apenas dois serviços:

* Serviço de Criptomoeda
* Serviço de Cotação

Base de dados: AWS DynamoDB
